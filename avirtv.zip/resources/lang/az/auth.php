<?php
return [
    'failed' => 'Məlumatlar düzgün deyil.',
    'throttle' => 'Giriş cəhdləri çoxdur. Xahiş edirəm yenidən cəhd edin :seconds saniyə.',
];
