<?php
return [
    'password' => 'Şifrə ən az 8 simvoldan ibarət olmalıdır və uyğunluğu yoxlayın.',
        'reset' => 'Şifrəniz yeniləndi!',
    'sent' => 'Elektron poçt ünvanınıza mail göndərildi',
    'token' => 'Bu kod istifadəyə yararlı deyil.',
    'user' => "Bu elektron poçt ünvanına sahib istifadəçi tapılmadı.",
];
