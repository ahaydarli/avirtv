<?xml version="1.0" encoding="UTF-8"?>
<response>
    <osmp_txn_id>{{ $osmp_txn_id }}</osmp_txn_id>
    <result>0</result>
    <comment>OK</comment>
    <addinfo>{{ $user->name }} {{ $user->email }} ||Current balance</addinfo>
</response>
