<?php


namespace App;


class Status
{

}
